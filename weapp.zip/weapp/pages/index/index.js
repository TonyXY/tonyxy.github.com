var app = getApp();
Page({
    data: {
    },
    goMap: function () {
        wx.openLocation({
          name:"泽林大咖",
          address:'这俩333',
          latitude: 31.230416,
          longitude: 121.473701,
          scale: 28
        })
    },
    goTel:function(){
      wx.makePhoneCall({
        phoneNumber: '18788881988' //仅为示例，并非真实的电话号码
      })
    },
    onLoad: function () {
        var that = this;
    },
    onShow: function () {
        var that = this;
    }
})
